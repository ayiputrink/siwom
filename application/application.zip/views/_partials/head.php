<meta charset="utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>SIWOM</title>
    <link rel="icon" type="image/ico" href="<?= base_url() ?>assets/images/favicon.ico" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?= base_url() ?>assets/js/vendor/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>assets/css/vendor/animsition.min.css">
    <!-- <link rel="stylesheet" href="<?= base_url() ?>assets/js/vendor/sweetalert/sweetalert2.css"> -->
    <link rel="stylesheet" href="<?= base_url() ?>assets/js/vendor/colorpicker/css/bootstrap-colorpicker.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>assets/js/vendor/touchspin/jquery.bootstrap-touchspin.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>assets/js/vendor/chosen/chosen.css">    
    <link rel="stylesheet" href="<?= base_url() ?>assets/js/vendor/datetimepicker/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>assets/css/main.css">
    <link rel="stylesheet" href="<?= base_url() ?>assets/css/vendor/datatables.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>assets/css/jquery-ui.css">
    
    <style>
        .swal2-popup {
           font-size: 1.6rem !important;
        }
    </style>