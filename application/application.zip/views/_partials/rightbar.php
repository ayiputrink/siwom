<aside id="rightmenu">
                <div role="tabpanel">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">
                        
                        <li role="presentation" class="active">
                            <a href="#todo" aria-controls="todo" role="tab" data-toggle="tab">Todo</a>
                        </li>
                        
                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content">
                        
                        <div role="tabpanel" class="tab-pane active" id="todo">
                            <div class="form-group">
                                <input type="text" value="" placeholder="Create new task..." class="form-control" />
                                <span class="fa fa-plus"></span>
                            </div>
                            <h6>Today</h6>
                            <ul class="todo-list">
                                <li>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="optionsCheckboxes"> Initialize the project</label>
                                    </div>
                                </li>
                                <li>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="optionsCheckboxes"> Create the main structure</label>
                                    </div>
                                </li>
                                <li>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="optionsCheckboxes"> Create the main structure</label>
                                    </div>
                                </li>
                            </ul>
                            <h6>Tomorrow</h6>
                            <ul class="todo-list">
                                <li>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="optionsCheckboxes"> Initialize the project</label>
                                    </div>
                                </li>
                                <li>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="optionsCheckboxes"> Create the main structure</label>
                                    </div>
                                </li>
                                <li>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="optionsCheckboxes"> displayed in a normal space!</label>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        
                    </div>
                </div>
            </aside>